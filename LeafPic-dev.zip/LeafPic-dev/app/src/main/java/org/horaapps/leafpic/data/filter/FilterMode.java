package org.horaapps.leafpic.data.filter;

/**
 * Created by dnld on 18/08/16.
 */

public enum FilterMode {
  ALL,
  IMAGES,
  GIF,
  VIDEO,
  NO_VIDEO
}
