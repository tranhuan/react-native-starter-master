package org.horaapps.leafpic.about;

/**
 * Created by dnld on 04/03/18.
 */

public interface ContactListener {
    void onContactClicked(Contact contact);
    void onMailClicked(String mail);
}
